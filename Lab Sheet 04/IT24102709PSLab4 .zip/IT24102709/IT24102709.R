##Exercise 
#1.
branch_data<-read.csv("Exercise.txt",header=TRUE)   #import dataset & store it in dataframe

#2.
str(branch_data)
summary(branch_data) 

#3.
boxplot(branch_data$Sales_X1,main = "Boxplot of Sales", outline=TRUE,outpch=8,horizontal=TRUE)

#4.
summary(branch_data$Advertising_X2) # five number summary of advertising
IQR(branch_data$Advertising_X2) #IQR for advertising

#5.
# Function to detect outliers using IQR rule
get_outliers <- function(x) {
  Q1 <- quantile(x)[2]
  Q3 <- quantile(x)[4]
  IQR_value <- Q3 - Q1     
  
  lower_bound <- Q1 - 1.5 * IQR_value
  upper_bound <- Q3 + 1.5 * IQR_value
  
  print(paste("Lower bound= ",lower_bound))
  print(paste("Upper bound= ",upper_bound))
  print(paste("Outliers: ",paste(sort(x[x<lower_bound | x>upper_bound]),collapse = ",")))
}

get_outliers(branch_data$Years_X3) #calling the function to check for outliers in years variables

